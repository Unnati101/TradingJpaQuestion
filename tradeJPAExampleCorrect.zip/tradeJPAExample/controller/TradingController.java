package com.example.tradeJPAExample.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.example.tradeJPAExample.model.Trading;
import com.example.tradeJPAExample.repository.TradingRepository;


@RestController
@RequestMapping("/trading")
public class TradingController {
	
	private final TradingRepository repo;

	public TradingController(TradingRepository repo) {
		super();
		this.repo = repo;
	}

	@PostMapping("/traders/register")
	public ResponseEntity<?> createT(@RequestBody Trading t){
		Trading exist = repo.findByEmail(t.getEmail());
		if(exist!=null) {
			return ResponseEntity.status(HttpStatus.CONFLICT).body("email already registered");

		}
		t.setCreatedAt(Trading.nowTime());
		t.setUpdatedAt("");
		Trading saved = repo.save(t);
		return ResponseEntity.status(HttpStatus.CREATED).body(saved);
	}
	
	@GetMapping("/traders/all")
	public ResponseEntity<List<Trading>> getAll(){
	  List<Trading> ls = repo.findAllByOrderByIdAsc();
	  return ResponseEntity.ok(ls);
	}
	
	
	@GetMapping("/email")
	public ResponseEntity<Trading> findByEmail(@RequestParam String email){
		//System.out.println("We are into the custom method");
		Trading t  = repo.findByEmail(email);
		
		if(t!=null) {
			return ResponseEntity.ok(t);
		}else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		
	}
	
	
	@PutMapping("/trading/traders")
	public ResponseEntity<Trading> updateModelName(@RequestBody Map<String, String> mp) {
	    String email = mp.get("email");
	    String name = mp.get("name");
	    Trading model=repo.findByEmail(email);
	    if(model==null) {
	    	return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	    }
	    model.setName(name);
	    repo.save( model);
	    return ResponseEntity.ok(model);
 
	}

	@PutMapping("/traders/add")
	public ResponseEntity<Trading> updateModelBal(@RequestBody Map<String, String> mp) {
	    double amt = Double.parseDouble(mp.get("amt"));
	    String email = mp.get("email");

	    Trading model = repo.findByEmail(email);
	    if (model == null) {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	    }

	    model.setBalance(model.getBalance() + amt);
	    model.setUpdatedAt(Trading.nowTime());
	    repo.save(model);
	    return ResponseEntity.ok(model);
	}

	
	
	
	
	
	
	
	
	

}
