package com.example.tradeJPAExample.model;



import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "traders")
public class Trading {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="trade_name" , nullable=false)
	private String name;
	
	@Column(name="trade_email", nullable= false)
	private String email;
	
	@Column(name="trade_bal" , nullable=false)
	private double balance;
	
	@Column(name="creation time")
	private String createdAt;
	
	@Column(name="up_d")
	private String UpdatedAt;
	
	
	public  Trading() {};
	
	public Trading(Long id, String name, String email, double balance) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.balance = balance;

	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public String getCreatedAt() {
	  return createdAt;
	}
	
	public void setCreatedAt(String createdAt) {
		this.createdAt=createdAt;
	}
	public String getUpdatedAt() {
		  return UpdatedAt;
		}
	
	
	
	public void setUpdatedAt(String updatedAt) {
		this.UpdatedAt=updatedAt;
	}
	
	
	public static String nowTime() {
		DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		return LocalDateTime.now().format(f);
	}
	
	

	
	
}
