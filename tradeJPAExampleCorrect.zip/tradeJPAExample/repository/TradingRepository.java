package com.example.tradeJPAExample.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.example.tradeJPAExample.model.Trading;

public interface TradingRepository extends JpaRepository<Trading, Long> {
	
//	@Transactional
//	@Query("Select t FROM Trading t where t.email = :email")
//    Optional<Trading> findByEmail(@Param("email") String email);
 Trading findByEmail(String Email);
	List<Trading> findAllByOrderByIdAsc();
	

}
